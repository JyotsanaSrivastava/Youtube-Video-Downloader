# Youtube-Video-Downloader

A simple application to download YouTube videos using Python. Tkinter API is used for GUI.

# About

YouTube is a very popular video-sharing website. Downloading a video’s/playlist from YouTube is a tedious task. 
Downloading that video through Downloader or trying to download it from a random website which increase’s the risk 
of licking your personal data. Using the Python Tkinter package, this task is very simple-efficient-safe. 
Few bunch codes will download the video for you. For this, there are two Python libraries – Tkinterand pytube.

